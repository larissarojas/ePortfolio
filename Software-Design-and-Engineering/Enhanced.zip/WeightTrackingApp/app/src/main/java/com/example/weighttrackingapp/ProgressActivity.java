package com.example.weighttrackingapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ProgressActivity extends AppCompatActivity {

    private EditText editTextWeight;
    private EditText editTextGoalWeight;
    private WeightAdapter adapter;
    private DatabaseHelper dbHelper;
    private List<String> weightEntries;
    private static final int SMS_PERMISSION_REQUEST_CODE = 101;
    private double userGoalWeight = -1;

    // progress UI
    private android.widget.ProgressBar progressBar;
    private android.widget.TextView progressLabel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_progress);

        dbHelper = new DatabaseHelper(this);

        editTextWeight = findViewById(R.id.editTextWeight);
        editTextGoalWeight = findViewById(R.id.editTextGoalWeight);
        Button buttonAddWeight = findViewById(R.id.buttonAddWeight);
        Button buttonSmsPermission = findViewById(R.id.buttonSmsPermission);

        // progress UI
        progressBar = findViewById(R.id.progressBar);
        progressLabel = findViewById(R.id.progressLabel);
        if (progressBar != null) progressBar.setMax(100);

        RecyclerView recyclerView = findViewById(R.id.recyclerViewWeights);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        weightEntries = dbHelper.getAllWeights();
        adapter = new WeightAdapter(this, weightEntries, dbHelper);
        recyclerView.setAdapter(adapter);

        // spacing between rows (4dp)
        int spacing = Math.round(4 * getResources().getDisplayMetrics().density);
        recyclerView.addItemDecoration(new RecyclerView.ItemDecoration() {
            @Override
            public void getItemOffsets(@NonNull android.graphics.Rect outRect,
                                       @NonNull android.view.View view,
                                       @NonNull RecyclerView parent,
                                       @NonNull RecyclerView.State state) {
                outRect.bottom = spacing;
            }
        });

        // initialize progress if possible
        updateProgressUI(getLatestWeightForUI());

        // ADD WEIGHT
        buttonAddWeight.setOnClickListener(v -> {
            String weightText = editTextWeight.getText().toString().trim();
            String goalText = editTextGoalWeight.getText().toString().trim();

            if (weightText.isEmpty()) {
                Toast.makeText(this, "Please enter your weight.", Toast.LENGTH_SHORT).show();
                return;
            }

            double weight;
            try {
                weight = Double.parseDouble(weightText);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Weight must be a number.", Toast.LENGTH_SHORT).show();
                return;
            }
            if (weight <= 0 || weight > 1400) {
                Toast.makeText(this, "Please enter a realistic weight.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!goalText.isEmpty()) {
                try {
                    userGoalWeight = Double.parseDouble(goalText);
                    if (userGoalWeight <= 0 || userGoalWeight > 1400) {
                        Toast.makeText(this, "Please enter a realistic goal weight.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(this, "Goal must be a number.", Toast.LENGTH_SHORT).show();
                    return;
                }
            }

            boolean success = dbHelper.addWeightEntry(weight);
            if (success) {
                Toast.makeText(this, getString(R.string.weight_added), Toast.LENGTH_SHORT).show();
                editTextWeight.setText("");

                // refresh from DB to keep order and avoid string parsing issues
                weightEntries.clear();
                weightEntries.addAll(dbHelper.getAllWeights());
                adapter.notifyDataSetChanged();

                // update progress
                updateProgressUI(getLatestWeightForUI());

                if (userGoalWeight > 0 && Math.abs(weight - userGoalWeight) < 0.01) {
                    sendGoalReachedSms();
                }
            } else {
                Toast.makeText(this, getString(R.string.error_saving_weight), Toast.LENGTH_SHORT).show();
            }
        });

        // SMS PERMISSION SCREEN
        buttonSmsPermission.setOnClickListener(v -> {
            Intent intent = new Intent(ProgressActivity.this, SmsPermissionActivity.class);
            startActivity(intent);
        });
    }

    // === helpers ===

    // parse the first (newest) entry like "150.0 lbs on 2025-09-18 03:10:00"
    private double getLatestWeightForUI() {
        if (weightEntries == null || weightEntries.isEmpty()) return -1;
        try {
            String first = weightEntries.get(0);
            String num = first.split(" lbs on ")[0];
            return Double.parseDouble(num);
        } catch (Exception e) {
            return -1;
        }
    }

    private void updateProgressUI(double latestWeight) {
        if (progressBar == null || progressLabel == null) return; // layout might not have them yet
        if (userGoalWeight <= 0 || latestWeight <= 0) {
            progressBar.setProgress(0);
            progressLabel.setText("Progress: —");
            return;
        }

        double start = dbHelper.getEarliestWeight();
        if (start <= 0 || start == userGoalWeight) {
            progressBar.setProgress(0);
            progressLabel.setText("Progress: —");
            return;
        }

        double pct;
        if (userGoalWeight < start) { // losing weight
            pct = (start - latestWeight) / (start - userGoalWeight);
        } else {                      // gaining weight
            pct = (latestWeight - start) / (userGoalWeight - start);
        }
        pct = Math.max(0, Math.min(1, pct)); // clamp

        int percent = (int) Math.round(pct * 100);
        progressBar.setProgress(percent);
        progressLabel.setText("Progress: " + percent + "%");
    }

    // === SMS ===
    private void sendGoalReachedSms() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            SmsManager smsManager = getSystemService(SmsManager.class);
            if (smsManager != null) {
                String phoneNumber = getString(R.string.sms_target_number);
                String message = getString(R.string.goal_sms_text);
                try {
                    smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                    Toast.makeText(this, getString(R.string.goal_sms_sent), Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Could not send SMS.", Toast.LENGTH_SHORT).show();
                }
            }
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, getString(R.string.permission_granted), Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS permission is required to send goal notifications.", Toast.LENGTH_LONG).show();
            }
        }
    }
}